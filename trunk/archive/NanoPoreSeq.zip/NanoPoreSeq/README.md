# NanoPoreSeq: simulated Nanopore BAMs of CNS tumours for Rapid-CNS2_nf

> This project is developed with the help of AI (Claude, Anthropic), under active review by
> Pierre Bady. Code, tests and documentation are produced with the assistant, then reviewed,
> discussed and validated by the author.

Scripts grouped by use. Each folder is self-contained: the scripts of one folder call each
other by their path in that folder, so keep each folder's files together.

## simulation/ — simulate BAMs, check them, classify their methylation

| Script | Role |
|---|---|
| `simulate_glioma_hg38.py` | Simulates one BAM (NPHD panel, hg38): profiles `gbm`, `astro`, `oligo` |
| `verify_bam.py` | Independent check of a simulated BAM (CNV, hotspots, MGMT, MM/ML tags) |
| `build_cohort.py` | Cohort of N individuals (parallel), optional classification of each BAM |
| `bedmethyl_from_bam.py` | bedMethyl from the MM/ML tags (replaces `modkit pileup --cpg --combine-strands`) |
| `methylation_classification_local.R` | Random-forest classification (Capper et al. data of Rapid-CNS2_nf) |
| `01_export_probe_targets.R` | One real representative methylation profile per class |
| `02_export_cohort_probe_targets.R` | N distinct real profiles per class (cohorts) |
| `run_full_mnp_classification.sh` | Simulation → bedMethyl → classification for one profile |
| `simnanocns_gui_en.py` | Streamlit interface for single samples and cohorts |

Requirements: Python 3 with `pysam` and `numpy` (`streamlit`, `pandas` for the interface);
R with `optparse`, `GenomicRanges`, `ranger`, `matrixStats`, `data.table`, `glmnet` for the
classification; the `data/` directory of Rapid-CNS2_nf.

```bash
# one sample, then its check
python3 simulation/simulate_glioma_hg38.py --profile gbm --ref hg38.fa --data-dir Rapid-CNS2_nf/data --out sim_gbm
python3 simulation/verify_bam.py --bam sim_gbm/SIM_GBM_HG38.bam --data-dir Rapid-CNS2_nf/data --ref hg38.fa
# complete chain with methylation classification
simulation/run_full_mnp_classification.sh --profile astro --data-dir Rapid-CNS2_nf/data --ref hg38.fa
# interface
streamlit run simulation/simnanocns_gui_en.py
```

## rapidcns2/ — run the Rapid-CNS2_nf pipeline

| Script | Role |
|---|---|
| `rapidcns2_gui_en.py` | Tkinter interface: pick a BAM, run Nextflow, follow progress, open the report |
| `align_fastq_rapidcns2_en.sh` | Real data: FASTQ → sorted, indexed hg38 BAM (dorado aligner + samtools) |

## usb/ — self-contained USB stick

| Script | Role |
|---|---|
| `make_usb_stick_en.sh` | All-in-one (device `/dev/sdX`, or mount folder of an already formatted stick): checks that the device is a removable stick (never a system disk), erases and formats it as ext4 after confirmation, mounts it, runs `prepare_usb_en.sh`, then `run.sh --check` |
| `prepare_usb_en.sh` | Copies pipeline, Nextflow, Java, containers, references and the interface onto an ext4 stick, and writes `run.sh` / `run_gui.sh` |

It takes the interface from `../rapidcns2/rapidcns2_gui_en.py` (or `GUI_PY=...`).
Quickest way: `./make_usb_stick_en.sh --list`, then `./make_usb_stick_en.sh --dry-run /dev/sdX`, then `./make_usb_stick_en.sh /dev/sdX -- --engine apptainer`.
On an already formatted stick: `./prepare_usb_en.sh --dry-run /media/$USER/STICK` first to check the sizes.
The full command sequence and the complete script are reproduced in the appendix of the user guide (section 12).

## docs/ — documentation

- User guide: `NanoPoreSeq_guide_utilisateur_FR.docx` (French) and `NanoPoreSeq_user_guide_EN.docx`
  (English): quick start, installation, how-to, command and file reference, troubleshooting.
- Review reports: `NanoPoreSeq_rapport_FR.docx` (French) and `NanoPoreSeq_report_EN.docx` (English):
  internal workings, function descriptions, corrections, tests and limits.
- Each document is provided as Word (`.docx`, editable) and PDF (`.pdf`, for reading and printing).

## Folder trees

Layout of the project and of the folders created by the scripts (default names). The user guide (section 8.5) gives the same trees in French and English.

### Project

Content of NanoPoreSeq.zip. The scripts of simulation/ call each other: they must stay in the same folder.

```
NanoPoreSeq/
├── README.md                                 overview of the folders
├── simulation/                               simulate, check, classify
│   ├── simulate_glioma_hg38.py               simulates a BAM
│   ├── verify_bam.py                         checks a BAM
│   ├── build_cohort.py                       simulates a cohort
│   ├── bedmethyl_from_bam.py                 BAM → bedMethyl
│   ├── methylation_classification_local.R    classifies the methylation
│   ├── 01_export_probe_targets.R             1 real profile per class
│   ├── 02_export_cohort_probe_targets.R      N real profiles per class
│   ├── run_full_mnp_classification.sh        complete chain
│   └── simnanocns_gui_en.py                  Streamlit interface
├── rapidcns2/                                run Rapid-CNS2_nf
│   ├── rapidcns2_gui_en.py                   Tkinter interface
│   └── align_fastq_rapidcns2_en.sh           FASTQ → BAM (real data)
├── usb/
│   ├── make_usb_stick_en.sh                  formats and creates the USB stick (all-in-one)
│   └── prepare_usb_en.sh                     copies the content onto the stick
└── docs/                                     guides and reports (FR, EN; .docx and .pdf)
```

### Simulated sample

Output of simulate_glioma_hg38.py (--out sim_gbm, gbm profile).

```
sim_gbm/                                      --out folder
├── SIM_GBM_HG38.bam                          simulated BAM (name = --sample-id)
├── SIM_GBM_HG38.bam.bai                      index
└── truth_events.tsv                          ground truth
```

### Classification of one sample

Outputs of 01_export_probe_targets.R and of the classification (procedure of section 6.3).

```
probe_targets/                                01_export_probe_targets.R
└── probe_targets_gbm.tsv, …_astro.tsv, …_oligo.tsv
classif_gbm/                                  run_full_mnp_classification.sh (-o)
├── <id>_calibrated_classification.tsv        predicted class, scores
├── <id>_votes.tsv, <id>_rf_details.tsv
├── <id>_methylation_hg38_HM450.RDS
└── <id>_probes_for_training.csv
```

### Cohort

Outputs of build_cohort.py and 02_export_cohort_probe_targets.R (default names).

```
cohort_bams/                                  --out-dir folder
├── cohort_manifest.tsv                       one individual per row, status
├── IND001_OLIGO.log                          simulation log
└── IND001_OLIGO/                             one folder per individual
    ├── IND001_OLIGO.bam (+ .bai)
    ├── IND001_OLIGO.bedmethyl.bed            with --classify
    └── truth_events.tsv
cohort_classification/                        with --classify (--classify-out-dir)
├── cohort_classification_summary.tsv         expected / predicted class
└── IND001_OLIGO/
    ├── …_calibrated_classification.tsv       predicted class
    ├── …_votes.tsv, …_rf_details.tsv
    ├── …_methylation_hg38_HM450.RDS
    ├── …_probes_for_training.csv
    └── …_classify.log                        prefix … = IND001_OLIGO
cohort_probes/                                02_export_cohort_probe_targets.R
├── probe_targets_gbm_01.tsv …                one file per individual and class
└── cohort_probe_manifest.tsv                 real sample used for each file
```

### Rapid-CNS2 results

With the rapidcns2_gui_en.py interface, whose default output is results_<id> in the launch folder.

```
<launch folder>/results_<id>/                 Rapid-CNS2_nf output
├── report/<id>_Rapid-CNS2_report_full.html   report (and _lite.html)
├── mods/<id>.5mC.bedmethyl                   methylation per CpG
├── mgmt/mgmt_avg_cov.txt                     MGMT coverage
└── pipeline_info/*_trace.txt                 step tracking
<launch folder>/work/                         Nextflow work (~150 GB/sample)
```

### USB stick

Created by make_usb_stick_en.sh (or prepare_usb_en.sh on an already formatted stick). The Nextflow work folder is not on the stick: it is created on the host's disk (~/rapidcns2_work by default, changeable with RCNS_WORKDIR).

```
/media/$USER/RAPIDCNS2/rapidcns2/
├── run.sh, run_gui.sh                        launchers
├── env.sh                                    shared environment
├── README.txt
├── bin/nextflow                              self-contained Nextflow
├── jre/                                      Java (unless --no-java)
├── pipeline/                                 Rapid-CNS2_nf
├── containers/sif/ or docker/                tool images
├── refs/                                     hg38.fa + .fai
├── annovar/                                  unless --no-annovar
├── annotsv/
├── conf/usb.config                           stick-specific settings
├── gui/                                      Rapid-CNS2 interface
├── samples/                                  copied BAMs (--with-samples)
├── results/<id>/                             analysis results
└── nxf_home/                                 Nextflow cache, plugins
```
